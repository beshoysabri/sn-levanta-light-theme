Fonts for the Levanta Dark and Levanta Light themes for Standard Notes
https://github.com/beshoysabri/sn-levanta-dark-theme

The web app and the iPhone and Android apps download these fonts on
their own. The desktop app (Windows, macOS, Linux) refuses to download
fonts, so install them on the computer once:

  Inter                 the app: sidebar, note list, menus, titles
  Karla                 English in the notes you write
  IBM Plex Sans Arabic  Arabic in the notes you write
  Levanta Arrows        turns -> => <-> and friends into arrows, in
                        English and in Arabic

Windows
  1. Extract this zip.
  2. Select all the .ttf files, right-click, and choose
     "Install for all users" ("Install" also works on most PCs; if a
     font doesn't show up, use "Install for all users").
  3. Quit Standard Notes completely, including from the icon in the
     system tray, and open it again. Fonts are read at launch.

macOS
  Double-click each .ttf and click Install (or drag them all into Font
  Book), then quit Standard Notes with Cmd+Q and open it again.

Linux
  Copy the .ttf files to ~/.local/share/fonts, run fc-cache -f, then
  restart Standard Notes.

Every font here is under the SIL Open Font License 1.1; see
LICENSE-FONTS.txt. Levanta Arrows is built from Karla and Inter.
